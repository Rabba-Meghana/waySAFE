import { Shield, AlertTriangle, Navigation2, Clock, TrendingUp } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { RouteDecision } from "@/api/waysafe";

interface RouteDecisionCardProps {
  decision: RouteDecision;
}

const RouteDecisionCard = ({ decision }: RouteDecisionCardProps) => {
  const isSafe = decision.decision === "safe";
  const riskLevel = decision.risk;

  const getRiskColor = (risk: number) => {
    if (risk < 30) return {
      bg: "from-success/20 to-success/10",
      border: "border-success/50",
      text: "text-success",
      glow: "shadow-success/20",
      icon: "text-success"
    };
    if (risk < 60) return {
      bg: "from-warning/20 to-warning/10",
      border: "border-warning/50",
      text: "text-warning",
      glow: "shadow-warning/20",
      icon: "text-warning"
    };
    return {
      bg: "from-destructive/20 to-destructive/10",
      border: "border-destructive/50",
      text: "text-destructive",
      glow: "shadow-destructive/20",
      icon: "text-destructive"
    };
  };

  const riskStyle = getRiskColor(riskLevel);

  return (
    <Card className={`p-8 bg-gradient-to-br ${riskStyle.bg} border-2 ${riskStyle.border} shadow-2xl hover:shadow-3xl transition-all duration-500 animate-slide-in-up backdrop-blur-sm`}>
      <div className="flex items-start justify-between mb-6">
        <div className="flex items-center space-x-4">
          <div
            className={`w-20 h-20 rounded-2xl flex items-center justify-center bg-gradient-to-br ${
              isSafe ? "from-success/30 to-success/10" : "from-destructive/30 to-destructive/10"
            } animate-float shadow-xl`}
          >
            {isSafe ? (
              <Shield className={`w-10 h-10 ${riskStyle.icon} drop-shadow-lg`} />
            ) : (
              <AlertTriangle className={`w-10 h-10 ${riskStyle.icon} drop-shadow-lg animate-pulse`} />
            )}
          </div>
          <div className="animate-scale-in">
            <h2 className={`text-4xl font-bold ${riskStyle.text} mb-1 drop-shadow-lg`}>
              Route {isSafe ? "Safe" : "Unsafe"}
            </h2>
            <p className="text-muted-foreground text-lg">Current route assessment</p>
          </div>
        </div>
        <div className="relative">
          <Badge
            className={`text-xl px-6 py-3 ${riskStyle.text} bg-gradient-to-r ${riskStyle.bg} border-2 ${riskStyle.border} shadow-lg animate-glow`}
          >
            <TrendingUp className="w-5 h-5 mr-2" />
            Risk: {riskLevel}%
          </Badge>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-6 mt-8">
        <div className="flex items-center space-x-4 p-5 bg-muted/30 backdrop-blur-sm rounded-xl border border-border/50 hover:bg-muted/50 transition-all duration-300 hover:scale-105 hover:shadow-lg">
          <div className="w-12 h-12 rounded-full bg-accent/20 flex items-center justify-center">
            <Navigation2 className="w-6 h-6 text-accent" />
          </div>
          <div>
            <p className="text-sm text-muted-foreground uppercase tracking-wide">Distance</p>
            <p className="text-2xl font-bold text-foreground">
              {(decision.route.distance / 1000).toFixed(1)} km
            </p>
          </div>
        </div>
        <div className="flex items-center space-x-4 p-5 bg-muted/30 backdrop-blur-sm rounded-xl border border-border/50 hover:bg-muted/50 transition-all duration-300 hover:scale-105 hover:shadow-lg">
          <div className="w-12 h-12 rounded-full bg-accent/20 flex items-center justify-center">
            <Clock className="w-6 h-6 text-accent" />
          </div>
          <div>
            <p className="text-sm text-muted-foreground uppercase tracking-wide">Duration</p>
            <p className="text-2xl font-bold text-foreground">
              {Math.round(decision.route.duration / 60)} min
            </p>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default RouteDecisionCard;
