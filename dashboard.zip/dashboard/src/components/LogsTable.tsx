import { Card } from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { LogEntry } from "@/api/waysafe";
import { formatDistanceToNow } from "date-fns";

interface LogsTableProps {
  logs: LogEntry[];
}

const LogsTable = ({ logs }: LogsTableProps) => {
  const getAgentColor = (agent: string) => {
    switch (agent) {
      case "signal_agent":
        return "bg-accent/20 text-accent border-accent/50";
      case "route_agent":
        return "bg-success/20 text-success border-success/50";
      case "memory_agent":
        return "bg-warning/20 text-warning border-warning/50";
      default:
        return "bg-muted/20 text-muted-foreground border-muted";
    }
  };

  return (
    <Card className="p-8 bg-gradient-to-br from-card via-card/95 to-card/80 border border-border/50 backdrop-blur-sm animate-slide-in-up">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-accent/20 flex items-center justify-center">
            <span className="text-2xl">📋</span>
          </div>
          <h3 className="text-2xl font-bold text-foreground">System Logs</h3>
        </div>
        <Badge className="text-sm px-4 py-2 bg-accent/20 text-accent border border-accent/30 animate-pulse">
          {logs.length} entries
        </Badge>
      </div>
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="border-border hover:bg-transparent">
              <TableHead className="text-foreground font-bold text-base">Time</TableHead>
              <TableHead className="text-foreground font-bold text-base">Agent</TableHead>
              <TableHead className="text-foreground font-bold text-base">Action</TableHead>
              <TableHead className="text-foreground font-bold text-base">Data</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {logs.map((log, index) => (
              <TableRow
                key={index}
                className="border-border/50 hover:bg-muted/50 transition-all duration-300 hover:scale-[1.01] animate-scale-in"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <TableCell className="text-muted-foreground font-mono text-sm">
                  <div className="flex items-center gap-2">
                    <div className="w-2 h-2 rounded-full bg-accent animate-pulse"></div>
                    {formatDistanceToNow(new Date(log.timestamp), {
                      addSuffix: true,
                    })}
                  </div>
                </TableCell>
                <TableCell>
                  <Badge className={`${getAgentColor(log.agent)} border shadow-sm`}>
                    {log.agent}
                  </Badge>
                </TableCell>
                <TableCell className="font-semibold text-foreground">
                  {log.action.replace(/_/g, " ")}
                </TableCell>
                <TableCell className="text-muted-foreground">{log.data}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </Card>
  );
};

export default LogsTable;
