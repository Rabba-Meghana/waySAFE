import { Card } from "@/components/ui/card";
import { MapPin } from "lucide-react";

interface RouteMapProps {
  isSafe: boolean;
}

const RouteMap = ({ isSafe }: RouteMapProps) => {
  return (
    <Card className="p-6 bg-gradient-to-br from-card to-card/90 h-[400px]">
      <h3 className="text-xl font-semibold mb-4 text-foreground">Route Visualization</h3>
      <div className="relative w-full h-[320px] bg-muted/30 rounded-xl overflow-hidden flex items-center justify-center">
        <div className="absolute inset-0 bg-gradient-to-br from-accent/10 to-primary/10" />
        <div className="relative z-10 text-center space-y-4">
          <div
            className={`w-20 h-20 mx-auto rounded-full flex items-center justify-center ${
              isSafe ? "bg-success/20" : "bg-destructive/20"
            }`}
          >
            <MapPin
              className={`w-10 h-10 ${
                isSafe ? "text-success" : "text-destructive"
              }`}
            />
          </div>
          <div>
            <p className="text-lg font-semibold text-foreground">
              Interactive Map
            </p>
            <p className="text-sm text-muted-foreground mt-2">
              Map visualization with Leaflet integration
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              Install react-leaflet and add your Mapbox token for full functionality
            </p>
          </div>
        </div>
      </div>
    </Card>
  );
};

export default RouteMap;
