// Mock API functions for waySAFE Dashboard
// Replace these with actual backend endpoints


export interface RouteDecision {
  decision: "safe" | "unsafe";
  risk: number;
  route: {
    geometry: string;
    distance: number;
    duration: number;
  };
}

export interface Metrics {
  alerts_processed: number;
  routes_checked: number;
  high_risk_events: number;
}

export interface LogEntry {
  timestamp: string;
  agent: string;
  action: string;
  data: string;
}

export interface MemoryEntry {
  event_type: string;
  severity: "low" | "medium" | "high";
  location: string;
}

// Mock data for demonstration
const mockRouteDecision: RouteDecision = {
  decision: "safe",
  risk: 25,
  route: {
    geometry: "polyline_string",
    distance: 2079.7,
    duration: 165.1,
  },
};

const mockMetrics: Metrics = {
  alerts_processed: 15,
  routes_checked: 28,
  high_risk_events: 3,
};

const mockLogs: LogEntry[] = [
  {
    timestamp: new Date().toISOString(),
    agent: "signal_agent",
    action: "processing_alert",
    data: "Large protest near Union Station",
  },
  {
    timestamp: new Date(Date.now() - 300000).toISOString(),
    agent: "route_agent",
    action: "route_check",
    data: "Checking alternative routes",
  },
  {
    timestamp: new Date(Date.now() - 600000).toISOString(),
    agent: "memory_agent",
    action: "storing_event",
    data: "High severity event logged",
  },
];

const mockMemory: MemoryEntry[] = [
  { event_type: "protest", severity: "high", location: "Union Station" },
  { event_type: "march", severity: "medium", location: "Navy Pier" },
  { event_type: "accident", severity: "low", location: "Michigan Avenue" },
];

export const getRouteDecision = async (): Promise<RouteDecision> => {
  // Simulate API call
  await new Promise((resolve) => setTimeout(resolve, 500));
  return mockRouteDecision;
};

export const getMetrics = async (): Promise<Metrics> => {
  await new Promise((resolve) => setTimeout(resolve, 500));
  return mockMetrics;
};

export const getLogs = async (): Promise<LogEntry[]> => {
  await new Promise((resolve) => setTimeout(resolve, 500));
  return mockLogs;
};

export const getMemory = async (): Promise<MemoryEntry[]> => {
  await new Promise((resolve) => setTimeout(resolve, 500));
  return mockMemory;
};
