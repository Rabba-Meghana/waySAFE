import { Card } from "@/components/ui/card";
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip } from "recharts";
import { Metrics } from "@/api/waysafe";

interface MetricsChartsProps {
  metrics: Metrics;
}

const MetricsCharts = ({ metrics }: MetricsChartsProps) => {
  const COLORS = {
    success: "hsl(142, 70%, 45%)",
    warning: "hsl(45, 95%, 55%)",
    danger: "hsl(0, 85%, 55%)",
    accent: "hsl(195, 100%, 60%)",
    neutral: "hsl(210, 50%, 30%)",
  };

  const alertsData = [
    { name: "Processed", value: metrics.alerts_processed },
    { name: "Pending", value: Math.max(5 - metrics.alerts_processed, 0) },
  ];

  const routesData = [
    { name: "Checked", value: metrics.routes_checked },
    { name: "Remaining", value: Math.max(50 - metrics.routes_checked, 0) },
  ];

  const eventsData = [
    { name: "High Risk", value: metrics.high_risk_events },
    { name: "Normal", value: Math.max(20 - metrics.high_risk_events, 0) },
  ];

  const renderChart = (data: any[], title: string, colors: string[], icon: string) => (
    <Card className="p-6 bg-gradient-to-br from-card via-card/95 to-card/80 border border-border/50 hover:shadow-2xl hover:scale-105 transition-all duration-500 animate-slide-in-up backdrop-blur-sm">
      <h3 className="text-xl font-bold mb-6 text-center text-foreground flex items-center justify-center gap-2">
        <span className="text-2xl">{icon}</span>
        {title}
      </h3>
      <ResponsiveContainer width="100%" height={220}>
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius={60}
            outerRadius={90}
            paddingAngle={8}
            dataKey="value"
            animationBegin={0}
            animationDuration={1200}
            animationEasing="ease-out"
          >
            {data.map((entry, index) => (
              <Cell 
                key={`cell-${index}`} 
                fill={colors[index % colors.length]}
                strokeWidth={2}
                stroke="hsl(var(--background))"
              />
            ))}
          </Pie>
          <Tooltip
            contentStyle={{
              backgroundColor: "hsl(var(--card))",
              border: "2px solid hsl(var(--border))",
              borderRadius: "1rem",
              padding: "12px",
              boxShadow: "0 10px 40px rgba(0,0,0,0.3)",
            }}
          />
          <Legend 
            wrapperStyle={{
              paddingTop: "20px",
              fontSize: "14px",
              fontWeight: "600",
            }}
          />
        </PieChart>
      </ResponsiveContainer>
      <div className="text-center mt-6 p-4 bg-muted/30 rounded-xl border border-border/30">
        <p className="text-4xl font-bold bg-gradient-to-r from-accent to-accent/70 bg-clip-text text-transparent animate-pulse">
          {data[0].value}
        </p>
        <p className="text-sm text-muted-foreground mt-1 uppercase tracking-wider">
          Total {data[0].name}
        </p>
      </div>
    </Card>
  );

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
      {renderChart(
        alertsData,
        "Alerts Processed",
        [COLORS.success, COLORS.neutral],
        "🔔"
      )}
      {renderChart(
        routesData,
        "Routes Checked",
        [COLORS.accent, COLORS.neutral],
        "🛣️"
      )}
      {renderChart(
        eventsData,
        "High Risk Events",
        [COLORS.danger, COLORS.success],
        "⚠️"
      )}
    </div>
  );
};

export default MetricsCharts;
