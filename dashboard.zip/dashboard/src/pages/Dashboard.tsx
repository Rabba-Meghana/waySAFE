import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { RefreshCw } from "lucide-react";
import { toast } from "@/hooks/use-toast";
import Navigation from "@/components/Navigation";
import RouteDecisionCard from "@/components/RouteDecisionCard";
import RouteMap from "@/components/RouteMap";
import MetricsCharts from "@/components/MetricsCharts";
import LogsTable from "@/components/LogsTable";
import MemoryTimeline from "@/components/MemoryTimeline";
import {
  getRouteDecision,
  getMetrics,
  getLogs,
  getMemory,
  RouteDecision,
  Metrics,
  LogEntry,
  MemoryEntry,
} from "@/api/waysafe";

const Dashboard = () => {
  const [loading, setLoading] = useState(false);
  const [routeDecision, setRouteDecision] = useState<RouteDecision | null>(null);
  const [metrics, setMetrics] = useState<Metrics | null>(null);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [memory, setMemory] = useState<MemoryEntry[]>([]);

  const fetchData = async () => {
    setLoading(true);
    try {
      const [decision, metricsData, logsData, memoryData] = await Promise.all([
        getRouteDecision(),
        getMetrics(),
        getLogs(),
        getMemory(),
      ]);

      setRouteDecision(decision);
      setMetrics(metricsData);
      setLogs(logsData);
      setMemory(memoryData);

      toast({
        title: "Dashboard Updated",
        description: "All data has been refreshed successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to fetch dashboard data",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <div className="min-h-screen bg-background relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-br from-accent/5 via-transparent to-primary/5 pointer-events-none"></div>
      
      <Navigation />
      
      <main className="container mx-auto px-6 py-10 space-y-10 relative z-10">
        <div className="flex items-center justify-between animate-scale-in">
          <div>
            <h2 className="text-4xl font-bold text-foreground bg-gradient-to-r from-accent to-foreground bg-clip-text text-transparent">
              Dashboard
            </h2>
            <p className="text-muted-foreground mt-2 text-lg flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-success animate-pulse"></span>
              Real-time route safety monitoring
            </p>
          </div>
          <Button
            onClick={fetchData}
            disabled={loading}
            size="lg"
            className="bg-gradient-to-r from-accent to-accent/80 hover:from-accent/90 hover:to-accent/70 text-primary-foreground shadow-xl hover:shadow-2xl transition-all duration-300 hover:scale-105 border-2 border-accent/30"
          >
            <RefreshCw className={`w-5 h-5 mr-2 ${loading ? "animate-spin" : ""}`} />
            Update Dashboard
          </Button>
        </div>

        {routeDecision && (
          <RouteDecisionCard decision={routeDecision} />
        )}

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2">
            {routeDecision && (
              <RouteMap isSafe={routeDecision.decision === "safe"} />
            )}
          </div>
          <div>
            {memory.length > 0 && <MemoryTimeline memory={memory} />}
          </div>
        </div>

        {metrics && <MetricsCharts metrics={metrics} />}

        {logs.length > 0 && <LogsTable logs={logs} />}
      </main>
    </div>
  );
};

export default Dashboard;
