import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin } from "lucide-react";
import { MemoryEntry } from "@/api/waysafe";

interface MemoryTimelineProps {
  memory: MemoryEntry[];
}

const MemoryTimeline = ({ memory }: MemoryTimelineProps) => {
  const getSeverityStyle = (severity: string) => {
    switch (severity) {
      case "high":
        return {
          bg: "bg-destructive",
          text: "text-destructive",
          border: "border-destructive/50",
          glow: "shadow-destructive/50"
        };
      case "medium":
        return {
          bg: "bg-warning",
          text: "text-warning",
          border: "border-warning/50",
          glow: "shadow-warning/50"
        };
      case "low":
        return {
          bg: "bg-success",
          text: "text-success",
          border: "border-success/50",
          glow: "shadow-success/50"
        };
      default:
        return {
          bg: "bg-muted",
          text: "text-muted-foreground",
          border: "border-muted",
          glow: ""
        };
    }
  };

  return (
    <Card className="p-8 bg-gradient-to-br from-card via-card/95 to-card/80 border border-border/50 backdrop-blur-sm animate-slide-in-up h-full">
      <div className="flex items-center gap-3 mb-8">
        <div className="w-10 h-10 rounded-lg bg-accent/20 flex items-center justify-center">
          <span className="text-2xl">🧠</span>
        </div>
        <h3 className="text-2xl font-bold text-foreground">
          Long-term Memory
        </h3>
      </div>
      <div className="space-y-8">
        {memory.map((entry, index) => {
          const style = getSeverityStyle(entry.severity);
          return (
            <div 
              key={index} 
              className="relative flex items-start space-x-4 group animate-scale-in"
              style={{ animationDelay: `${index * 150}ms` }}
            >
              <div className="flex flex-col items-center">
                <div
                  className={`w-5 h-5 rounded-full ${style.bg} ring-4 ring-${style.bg}/20 shadow-lg ${style.glow} animate-pulse`}
                />
                {index < memory.length - 1 && (
                  <div className={`w-1 h-20 bg-gradient-to-b from-${style.bg} to-border/50 mt-2`} />
                )}
              </div>
              <div className="flex-1 pb-8 bg-muted/20 p-4 rounded-xl border border-border/30 hover:bg-muted/40 transition-all duration-300 hover:scale-105">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-bold text-foreground capitalize text-lg flex items-center gap-2">
                    <span className={`w-2 h-2 rounded-full ${style.bg} animate-ping`}></span>
                    {entry.event_type}
                  </h4>
                  <Badge className={`${style.text} bg-${style.bg}/20 border ${style.border} px-3 py-1 font-bold`}>
                    {entry.severity.toUpperCase()}
                  </Badge>
                </div>
                <div className="flex items-center text-muted-foreground bg-muted/30 p-2 rounded-lg">
                  <MapPin className="w-4 h-4 mr-2 text-accent" />
                  <span className="text-sm font-medium">{entry.location}</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </Card>
  );
};

export default MemoryTimeline;
