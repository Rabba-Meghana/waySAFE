import { Activity, Waves, Radio } from "lucide-react";
import { ThemeToggle } from "./ThemeToggle";

const Navigation = () => {
  return (
    <nav className="bg-gradient-to-r from-primary via-primary/95 to-primary shadow-2xl border-b-4 border-accent/30 backdrop-blur-lg sticky top-0 z-50 relative overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-r from-accent/10 via-success/5 to-accent/10 animate-pulse"></div>
      <div className="container mx-auto px-6 py-6 relative z-10">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-5 animate-scale-in">
            <div className="w-14 h-14 bg-gradient-to-br from-accent via-accent/80 to-accent/60 rounded-2xl flex items-center justify-center shadow-2xl animate-glow ring-4 ring-accent/20">
              <Activity className="w-8 h-8 text-primary-foreground drop-shadow-lg" />
            </div>
            <div>
              <h1 className="text-4xl font-black tracking-tight bg-gradient-to-r from-accent via-accent/90 to-accent/70 bg-clip-text text-transparent drop-shadow-2xl">
                waySAFE
              </h1>
              <p className="text-xs text-muted-foreground font-semibold mt-0.5 tracking-wider uppercase">
                Intelligent Route Safety
              </p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="flex items-center space-x-4 bg-gradient-to-r from-success/30 via-success/20 to-success/30 border-3 border-success/50 px-6 py-3.5 rounded-2xl shadow-2xl animate-glow ring-4 ring-success/10 backdrop-blur-md">
              <div className="relative flex items-center justify-center">
                <div className="w-4 h-4 bg-success rounded-full animate-pulse shadow-lg shadow-success/50"></div>
                <div className="absolute inset-0 w-4 h-4 bg-success rounded-full animate-ping"></div>
                <div className="absolute inset-0 w-4 h-4 bg-success/40 rounded-full animate-ping" style={{ animationDelay: '0.5s' }}></div>
              </div>
              <Radio className="w-5 h-5 text-success animate-pulse drop-shadow-lg" />
              <div className="flex flex-col">
                <span className="text-base font-black text-success uppercase tracking-wider drop-shadow-lg">LIVE</span>
                <span className="text-xs font-bold text-success/80">Monitoring Active</span>
              </div>
            </div>
            
            <ThemeToggle />
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navigation;
